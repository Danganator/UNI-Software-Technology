import tkinter as tk
from tkinter import messagebox, ttk
import time
import random
import string
import matplotlib.pyplot as plt

# ===== AVL Node and AVL Tree Class =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        # Normal BST insert
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            # Update phone if name exists
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        # Rotations
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Balancing
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

# ===== BST Node and BST Class =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            # Node with one or no children
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            # Node with two children
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

# ===== Red-Black Tree =====

RED = True
BLACK = False

class RBTNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.color = RED

class RedBlackTree:
    def __init__(self):
        self.root = None

    def is_red(self, node):
        if node is None:
            return False
        return node.color == RED

    def rotate_left(self, h):
        x = h.right
        h.right = x.left
        x.left = h
        x.color = h.color
        h.color = RED
        return x

    def rotate_right(self, h):
        x = h.left
        h.left = x.right
        x.right = h
        x.color = h.color
        h.color = RED
        return x

    def flip_colors(self, h):
        h.color = RED
        h.left.color = BLACK
        h.right.color = BLACK

    def insert(self, root, name, phone):
        if root is None:
            return RBTNode(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
            return root

        if self.is_red(root.right) and not self.is_red(root.left):
            root = self.rotate_left(root)

        if self.is_red(root.left) and self.is_red(root.left.left if root.left else None):
            root = self.rotate_right(root)

        if self.is_red(root.left) and self.is_red(root.right):
            self.flip_colors(root)

        return root

    def insert_contact(self, name, phone):
        self.root = self.insert(self.root, name, phone)
        self.root.color = BLACK

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def find_min(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def delete_contact(self, name):
        self.root = self.delete(self.root, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res

# ===== Benchmarking Function =====

def benchmark(n=100000, search_fraction=0.5, delete_count=100, verbose=True):
    # Generate test data
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    # --- BST benchmark ---
    bst = BST()
    bst.root = None

    # Insert
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    # Search
    search_names = random.sample(names, int(n*search_fraction)) + ['notfoundname'] * int(n*(1 - search_fraction))
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start

    # Delete
    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    # --- AVL benchmark ---
    avl = AVLTree()
    avl.root = None

    # Insert
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    # Search
    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start

    # Delete
    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    # --- RBT benchmark ---
    rbt = RedBlackTree()

    # Insert
    start = time.time()
    for i in range(n):
        rbt.insert_contact(names[i], phones[i])
    rbt_insert_time = time.time() - start

    # Search
    start = time.time()
    found_rbt = sum(1 for name in search_names if rbt.search(rbt.root, name))
    rbt_search_time = time.time() - start

    # Delete
    start = time.time()
    for name in delete_names:
        rbt.delete_contact(name)
    rbt_delete_time = time.time() - start

    # Prepare results
    results = {
        'Insertions': (bst_insert_time, avl_insert_time, rbt_insert_time),
        'Searches': (bst_search_time, avl_search_time, rbt_search_time),
        'Deletions': (bst_delete_time, avl_delete_time, rbt_delete_time),
        'Found In Search': (found_bst, found_avl, found_rbt)
    }

    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation      BST Time (sec)    AVL Time (sec)    RBT Time (sec)")
        print("------------------------------------------------------------------")
        print(f"Insertions:    {bst_insert_time:.6f}            {avl_insert_time:.6f}            {rbt_insert_time:.6f}")
        print(f"Searches:      {bst_search_time:.6f}            {avl_search_time:.6f}            {rbt_search_time:.6f}")
        print(f"Deletions:     {bst_delete_time:.6f}            {avl_delete_time:.6f}            {rbt_delete_time:.6f}")
        print("------------------------------------------------------------------")
        print(f"Contacts found in search:")
        print(f"BST: {found_bst} / {len(search_names)}")
        print(f"AVL: {found_avl} / {len(search_names)}")
        print(f"RBT: {found_rbt} / {len(search_names)}")
    return results

# ===== Tkinter GUI App =====

class RBTApp:
    def __init__(self, master):
        self.rbt = RedBlackTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")

        # Input frame
        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1)

        # Buttons
        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert",
                  command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search",
                  command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Delete",
                  command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Show All",
                  command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(self.btn_frame, text="Run Benchmark",
                  command=self.run_benchmark).grid(row=0, column=4, padx=5)

        # Output text box
        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        # Canvas for tree visualization
        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

        # Treeview table for benchmark results
        self.tree = ttk.Treeview(master, columns=("BST", "AVL", "RBT"), show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RBT Time (s)")
        self.tree.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.rbt.insert_contact(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return
        node = self.rbt.search(self.rbt.root, name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to delete.")
            return
        self.rbt.delete_contact(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.rbt.inorder(self.rbt.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.output_text.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if not self.rbt.root:
            return
        width = self.canvas.winfo_width()
        self._draw_node(self.rbt.root, width // 2, 20, width // 4)

    def _draw_node(self, node, x, y, x_offset):
        if not node:
            return
        radius = 20

        if node.left:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, x_offset // 2)

        if node.right:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, x_offset // 2)

        color = "red" if node.color == RED else "black"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                 fill=color)
        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        self.canvas.create_text(x, y, text=display_name,
                                 font=("Arial", 10, "bold"), fill="white")

    def run_benchmark(self):
        self.output_text.delete(1.0, tk.END)
        results = benchmark(verbose=False)  # silent print

        # Display text summary
        summary = (
            f"Insertion Time: BST: {results['Insertions'][0]:.6f}s, AVL: {results['Insertions'][1]:.6f}s, RBT: {results['Insertions'][2]:.6f}s\n"
            f"Search Time:    BST: {results['Searches'][0]:.6f}s, AVL: {results['Searches'][1]:.6f}s, RBT: {results['Searches'][2]:.6f}s\n"
            f"Deletion Time:  BST: {results['Deletions'][0]:.6f}s, AVL: {results['Deletions'][1]:.6f}s, RBT: {results['Deletions'][2]:.6f}s\n"
            f"Found in Search: BST: {results['Found In Search'][0]}, AVL: {results['Found In Search'][1]}, RBT: {results['Found In Search'][2]} out of 1000\n"
        )
        self.output_text.insert(tk.END, summary)

        # Clear previous treeview
        for row in self.tree.get_children():
            self.tree.delete(row)

        # Insert new data rows
        for op in ['Insertions', 'Searches', 'Deletions']:
            bst_time, avl_time, rbt_time = results[op]
            self.tree.insert('', tk.END, values=(f"{bst_time:.6f}", f"{avl_time:.6f}", f"{rbt_time:.6f}"), text=op)

# Re-use BST and AVL classes from previous code
# Use BST and AVLTree classes already defined with
# insert/search/delete methods.

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # --- BST ---
        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        # --- AVL ---
        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        # --- RBT ---
        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.insert_contact(names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            rbt.search(rbt.root, name)
        rbt_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            rbt.delete_contact(name)
        rbt_times['delete'].append(time.time() - start)

    # Plot results
    plt.figure(figsize=(12, 8))

    # Insertions plot
    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    # Searches plot
    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rbt_times['search'], label='RBT Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    # Deletions plot
    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()

# Example usage:
if __name__ == "__main__":
    root = tk.Tk()
    app = RBTApp(root)
    root.mainloop()
    sizes_to_test = [100, 500, 1000, 2000, 5000, 10000]
    run_benchmark_for_sizes(sizes_to_test)