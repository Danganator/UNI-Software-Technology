import tkinter as tk
import math

class KochSnowflake:
    def __init__(self):
        window = tk.Tk()
        window.title("Koch Snowflake")

        self.width, self.height = 400, 500
        self.snowflakewidth = 400
        self.snowflakeheight = 400
    
        self.canvas = tk.Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame = tk.Frame(window)
        frame.pack()

        tk.Label(frame, text="Enter an order: ").pack(side=tk.LEFT)

        self.order = tk.StringVar()
        tk.Entry(frame, textvariable=self.order, justify=tk.RIGHT).pack(side=tk.LEFT)

        tk.Button(frame, text="Display Koch Snowflake", command=self.display).pack(side=tk.LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        order = int(self.order.get())

        # Define triangle RELATIVE to canvas size
        margin = 20
        p1 = [self.snowflakewidth / 2, margin]
        p2 = [margin, self.snowflakeheight - margin]
        p3 = [self.snowflakewidth - margin, self.snowflakeheight - margin]

        # Draw 3 Koch sides
        self.displayKoch(order, p1, p2)
        self.displayKoch(order, p2, p3)
        self.displayKoch(order, p3, p1)

    def displayKoch(self, order, p1, p2):
        if order == 0:
            self.drawLine(p1, p2)
        else:
            # Divide line into 3 parts
            pA = p1
            pB = self.point_on_line(p1, p2, 1/3)
            pD = self.point_on_line(p1, p2, 2/3)
            pE = p2

            # Create peak of triangle
            pC = self.get_peak(pB, pD)

            # Recursive calls (same style as Sierpinski)
            self.displayKoch(order - 1, pA, pB)
            self.displayKoch(order - 1, pB, pC)
            self.displayKoch(order - 1, pC, pD)
            self.displayKoch(order - 1, pD, pE)

    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")

    def point_on_line(self, p1, p2, fraction):
        return [
            p1[0] + (p2[0] - p1[0]) * fraction,
            p1[1] + (p2[1] - p1[1]) * fraction
        ]

    def get_peak(self, pB, pD):
        # Vector from B to D
        dx = pD[0] - pB[0]
        dy = pD[1] - pB[1]

        # Rotate 60 degrees
        angle = math.radians(60)
        x = pB[0] + math.cos(angle) * dx - math.sin(angle) * dy
        y = pB[1] + math.sin(angle) * dx + math.cos(angle) * dy

        return [x, y]

KochSnowflake()