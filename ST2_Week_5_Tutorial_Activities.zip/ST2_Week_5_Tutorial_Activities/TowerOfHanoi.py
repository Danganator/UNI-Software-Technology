def main():
    n = eval(input("Enter number of disks: ")) 
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower

def moveDisks(n, fromTower, toTower, auxTower):
    global totalMoves
    if n == 1: # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
    totalMoves += 1

totalMoves = 0
main() # Call the main function
print(f"Total Moves: {totalMoves}")