import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 200

class QueueVisualiser:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualiser")

        self.queue = deque()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.Push_entry = tk.Entry(control_frame, width=10)
        self.Push_entry.grid(row=0, column=1)

        Push_btn = tk.Button(control_frame, text="Push", command=self.Push_value)
        Push_btn.grid(row=0, column=2, padx=5)

        Pop_btn = tk.Button(control_frame, text="Pop", command=self.Pop_value)
        Pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        rect = self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, text=str(data), font=("Arial", 16))
        return rect

    def draw_queue(self):
        self.canvas.delete("all")

        if not self.queue:
            return

        # Calculate total width of queue
        total_width = len(self.queue) * NODE_WIDTH + (len(self.queue) - 1) * HORIZONTAL_GAP

        # Center horizontally
        start_x = (CANVAS_WIDTH - total_width) // 2

        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2

        # Draw nodes
        for i, val in enumerate(self.queue):
            x = start_x + i * (NODE_WIDTH + HORIZONTAL_GAP)
            self.draw_node(x, y, val)

        # Draw Front label
        self.canvas.create_text(start_x + NODE_WIDTH // 2, y - 20, text="Front", font=("Arial", 12), fill="red")

        # Draw Rear label
        rear_x = start_x + (len(self.queue) - 1) * (NODE_WIDTH + HORIZONTAL_GAP)
        self.canvas.create_text( rear_x + NODE_WIDTH // 2, y - 20, text="Rear", font=("Arial", 12), fill="green")

    def Push_value(self):
        try:
            val = int(self.Push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to Push.")
            return
        self.queue.append(val)
        self.Push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushd {val} into queue")
        self.draw_queue()

    def Pop_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot Pop.")
            return
        val = self.queue.popleft()
        self.status_label.config(text=f"Popd {val} from queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualiser(root)

    # Example test cases:
    # app.queue = deque([10, 20, 30])
    # app.draw_queue()
    root.mainloop()